package betterLeJOSColorsSampleProject;

import betterLeJOSColorsSampleProject.view.Tui;

/**
 * Driver class to start program
 * 
 * @author Nathan Beam 
 * @version Fall 2016
 */
public class Driver {

	/**
	 * Main method
	 * @param args command line args, no-op
	 */
	public static void main(String[] args) {
		Tui tui = new Tui();
		tui.run();
	}

}
