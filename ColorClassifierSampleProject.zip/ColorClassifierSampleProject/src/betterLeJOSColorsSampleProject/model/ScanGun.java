package betterLeJOSColorsSampleProject.model;

import betterLeJOSColors.controller.Classifier;
import betterLeJOSColors.model.Color;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3TouchSensor;
import lejos.robotics.SampleProvider;

/**
 * Class representing the physical scanner
 * 
 * @author Nathan Beam & Matt Maginniss
 * @version Fall 2016
 */
public class ScanGun {

	private EV3ColorSensor colorSensor;
	private EV3TouchSensor trigger;
	private Classifier classifier;

	/**
	 * Constructs a new scanGun
	 * 
	 * @param colorSensorPort
	 *            the Port with the color sensor
	 * @param touchSensorPort
	 *            the Port with the touch sensor
	 * @param classifier
	 *            the Classifier object to use
	 */
	public ScanGun(Port colorSensorPort, Port touchSensorPort, Classifier classifier) {
		this.colorSensor = new EV3ColorSensor(colorSensorPort);
		this.trigger = new EV3TouchSensor(touchSensorPort);
		this.classifier = classifier;
	}

	/**
	 * Returns true if the touch sensor is pressed
	 *
	 * @precondition none
	 * @postcondition none
	 * @return whether the "trigger" is pressed all the way down
	 */
	public boolean triggerPulled() {
		SampleProvider touch = this.trigger.getTouchMode();
		float[] touchSample = new float[touch.sampleSize()];
		touch.fetchSample(touchSample, 0);
		return touchSample[0] == 1;
	}

	/**
	 * Gets a new Color object from the input values of the color scanner
	 *
	 * @precondition none
	 * @postcondition none
	 * @return new Color object
	 */
	public Color getColor() {
		SampleProvider colorProvider = this.colorSensor.getRGBMode();
		float[] colorSample = new float[colorProvider.sampleSize()];
		colorProvider.fetchSample(colorSample, 0);

		float red = colorSample[0];
		float green = colorSample[1];
		float blue = colorSample[2];

		return new Color(red, green, blue);

	}

	/**
	 * Adds a scanned in color to the classifier
	 *
	 * @precondition color is not null, name is not null
	 * @postcondition a scanned in Color is added to the ScanList
	 * @param color
	 *            the Color object
	 * @param colorName
	 *            the name of the color
	 */
	public void addScan(Color color, String colorName) {
		if (color == null || colorName == null) {
			return;
		}
		color.setColorName(colorName);
		this.classifier.addColor(color);
	}

}
