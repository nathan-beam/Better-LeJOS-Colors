package betterLeJOSColorsSampleProject.view;

import java.io.IOException;

import betterLeJOSColors.controller.Classifier;
import betterLeJOSColors.model.Color;
import betterLeJOSColorsSampleProject.controller.Keyboard;
import betterLeJOSColorsSampleProject.model.ScanGun;
import lejos.hardware.Button;
import lejos.hardware.lcd.LCD;
import lejos.hardware.port.SensorPort;
import lejos.utility.Delay;

/**
 * Tui Class
 *
 * @author Nathan Beam & Matt Maginniss
 * @version Fall 2016
 */
public class Tui {

	private ScanGun gun;

	private enum Option {
		TRAIN, RUN, QUIT
	}

	private Option selectedOption;
	private boolean loaded;
	private Classifier classifier;
	private static final String FILE_PATH = "/home/lejos/saves/colors.arff";

	/**
	 * Constructor for TUI class
	 */
	public Tui() {
		this.classifier = new Classifier(FILE_PATH);
		this.gun = new ScanGun(SensorPort.S4, SensorPort.S1, this.classifier);
		this.selectedOption = Option.TRAIN;
	}

	/**
	 * Main driver method for TUI
	 *
	 * @precondition none
	 * @postcondition the program has finished running
	 */
	public void run() {
		boolean listening = true;
		while (listening) {
			this.constructMenu();
			switch (Button.waitForAnyPress()) {
				case Button.ID_UP:
					this.up();
					break;
				case Button.ID_DOWN:
					this.down();
					break;
				case Button.ID_ENTER:
					this.select();
					break;
				default:
					break;
			}
		}
	}

	private void select() {
		if (this.selectedOption == Option.TRAIN) {
			this.prepFile();
			this.trainColors();
			try {
				this.classifier.save();
			} catch (IOException e) {
				this.drawError();

			}
		} else if (this.selectedOption == Option.QUIT) {
			System.exit(0);
		} else {
			this.runClassifier();
		}
	}

	private void drawError() {
		LCD.clear();
		LCD.drawString("Error!", 0, 0);
		LCD.drawString("Reboot or retry", 0, 1);
	}

	private void runClassifier() {
		try {
			LCD.clear();
			LCD.drawString("Classifying data", 0, 0);
			this.classifier.generateClassifier();
			LCD.clear();
			LCD.drawString("Scan to identify", 0, 0);
			LCD.drawString("Your color:", 0, 2);
			while (true) {
				boolean triggerDown = false;
				while (!triggerDown) {
					if (this.gun.triggerPulled()) {
						triggerDown = true;
						Color color = this.gun.getColor();
						String label = this.classifier.classifyColor(color);
						LCD.drawString("                                          ", 0, 3);
						LCD.drawString(label, 0, 3);
					}
					Delay.msDelay(40);
				}
				this.waitForTriggerRelease();
			}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	private void prepFile() {
		LCD.clear();
		LCD.drawString("Append   Overwrite", 0, 3);
		LCD.drawString(" |             | ", 0, 4);
		LCD.drawString(" |             | ", 0, 5);
		LCD.drawString(" V             V ", 0, 6);

		Delay.msDelay(100);
		boolean listening = true;
		while (listening) {
			switch (Button.waitForAnyPress()) {
				case Button.ID_LEFT:
					try {
						this.classifier.loadColors();
					} catch (IOException e) {
						this.drawError();
					}
				case Button.ID_RIGHT:
					listening = false;
					break;
				default:
					break;
			}
		}

	}

	private void up() {
		if (this.selectedOption == Option.TRAIN) {
			if (this.loaded) {
				this.selectedOption = Option.RUN;
			} else {
				this.selectedOption = Option.QUIT;
			}
		} else if (this.selectedOption == Option.QUIT) {
			this.selectedOption = Option.TRAIN;
		} else {
			this.selectedOption = Option.QUIT;
		}
		this.constructMenu();
	}

	private void down() {
		if (this.selectedOption == Option.TRAIN) {
			this.selectedOption = Option.QUIT;
		} else if (this.selectedOption == Option.QUIT) {
			if (this.loaded) {
				this.selectedOption = Option.RUN;
			} else {
				this.selectedOption = Option.TRAIN;
			}
		} else {
			this.selectedOption = Option.TRAIN;
		}
		this.constructMenu();
	}

	private void setCursor() {
		if (this.selectedOption == Option.TRAIN) {
			LCD.drawChar('>', 0, 3);
		} else if (this.selectedOption == Option.QUIT) {
			LCD.drawChar('>', 0, 5);
		} else {
			LCD.drawChar('>', 0, 1);
		}
	}

	private void constructMenu() {
		this.loaded = this.classifier.fileExistsAndIsGood();
		LCD.clear();
		LCD.drawString("Train", 1, 3);
		LCD.drawString("Quit", 1, 5);
		if (this.loaded) {
			LCD.drawString("Run", 1, 1);
		}
		this.setCursor();
	}

	private void trainColors() {
		String color = Keyboard.getString();
		while (color != null) {
			LCD.clear();
			LCD.drawString(color, 0, 5);
			this.promptColor(this.gun, color);
			color = Keyboard.getString();
		}
		LCD.clear();
		LCD.drawString("Scan Successful!", 0, 3);
		Delay.msDelay(1500);
	}

	private void promptColor(ScanGun gun, String colorName) {
		for (int i = 0; i < 3; i++) {
			boolean triggerDown = false;
			while (!triggerDown) {
				LCD.drawString("Scan #" + (i + 1), 0, 4);
				if (i > 0) {
					LCD.drawString("Please scan again", 0, 3);
				} else {
					LCD.drawString("                            ", 0, 3);
				}
				if (gun.triggerPulled()) {
					triggerDown = true;
					Color scan = this.gun.getColor();
					gun.addScan(scan, colorName);
				}
				Delay.msDelay(40);
			}
			this.waitForTriggerRelease();
		}
	}

	private void waitForTriggerRelease() {
		boolean triggerDown = true;
		while (triggerDown) {
			triggerDown = this.gun.triggerPulled();
		}
	}

}
